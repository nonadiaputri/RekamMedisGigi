<!DOCTYPE html>
<html>
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <title></title>
</head>
<body>
  <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Tables</h2>
            </div>
          </header>
          <div class="breadcrumb-holder container-fluid">
            <ul class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html">Home</a></li>
              <li class="breadcrumb-item active">Pasien            </li>
            </ul>
          </div>

  <section class="tables">   
            <div class="container-fluid">
              <div class="row">
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Compact Table</h3>
                    </div>
                    <div class="card-body">
                      <table class="table table-striped table-sm">
                        <thead>
                          <tr>
                            <th style="width: 5%; text-align:center;">No.</th>
                            <th style="width: 35%; text-align:left;">Nama</th>
                            <th style="width: 35%; text-align:left;">Email</th>
                            <th style="width: 25%; text-align:center;">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php 
                            $num=1;
                            foreach ($dokter as $key) { ?>
                          <tr id="<?php echo $key->id_staff;?>">
                            <td style="text-align:center;"><?php echo $num; ?></td>
                            <td><?php echo $key->fullname; ?></td>
                            <td><?php echo $key->email; ?></td>
                            <td style="text-align:center;">
                              
                              <a href="" class="btn btn-danger" role="button" data-toggle="modal" data-target="#myModal" >Hapus</a>
                              <?php $id = $key->id_staff; ?>
                              <a href="<?php echo base_url('c_admin/ubahdt_staff/').$key->id_staff; ?>" class="btn btn-success" role="button">Edit</a>
                              <a id="btn-lihat" class="btn btn-info" role="button">Lihat</a>
                            </td>
                          </tr>
                          <?php } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                </div>
            </div>
          </section>
        

          <div class="modal fade" id="lihat_staff" role="dialog">
        <div class="modal-dialog">
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header" style="background: #4787ef">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title" align="center"></h4>
            </div>
            <div class="modal-body">
              <table class="table" id="tabel-lihat">
                      <tr>
                        <th>Nama Depan</th>
                        <td id="firstname"></td>
                      </tr>
                      <tr>
                        <th>Nama Belakang</th>
                        <td id="lastname"></td>
                      </tr>
                      <tr>
                        <th>Username</th>
                        <td id="username"></td>
                      </tr>
                      <tr>
                        <tr>
                        <th>Nomor SIP</th>
                        <td id="no_sip"></td>
                      </tr>
                      <tr>
                        <th>Email</th>
                        <td id="email"></td>
                      </tr>
                      <tr>
                        <th>Jenis Kelamin</th>
                        <td id="gender"></td>
                      </tr>
                      <tr>
                        <th>Pekerjaan</th>
                        <td id="job"></td>
                      </tr>
                      <tr>
                        <th>Alamat</th>
                        <td id="alamat"></td>
                      </tr>
                      <tr>
                        <th>Nomor Handphone</th>
                        <td id="no_hp"></td>
                      </tr>
                    </table>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal" style="float: center;">OK</button>
            </div>
          </div>
        </div>
      </div>
      
      <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
      <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete</h4>
      </div>
      <div class="modal-body">
        <p>Are you sure want to delete? </p>
      </div>
      <div class="modal-footer">
          <a  href="" class="btn btn-default" id="btn_yes" >Yes</a>
        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        
      </div>
    </div>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


<script>
  $(document).ready(function () {
    var id = <?php echo $id; ?>;

    $(".btn-info").click(function(){
    var id_staff = $(this).closest('tr').attr('id')
    $.ajax({
        url:"<?php echo base_url('c_admin/perstaff/');?>" + id_staff,
        type:"POST",
        dataType:'JSON',
        success:function(data){
          $('#lihat_staff').modal('show');
          $('#firstname').html(data.mem[0].firstname);
          $('#lastname').html(data.mem[0].lastname);
          $('#username').html(data.mem[0].username);
          $('#email').html(data.mem[0].email);
          $('#gender').html(data.mem[0].gender);
          $('#job').html(data.mem[0].job);
          $('#alamat').html(data.mem[0].alamat);
          $('#no_sip').html(data.mem[0].no_sip);
          $('#no_hp').html(data.mem[0].no_hp);
          },
        error:function(){
          alert('error ... ');
        }
      });
  })

function doconfirm()
{
    job=confirm("Are you sure to delete permanently?");
    if(job!=true)
    {
        return false;
    }
}

function show_confirm() {
    var r = confirm("Press the button");
    if (r == true) {
        alert("You are right");
    } else {
        alert("You are wrong");
    }
}

});

</script>
</body>
</html>