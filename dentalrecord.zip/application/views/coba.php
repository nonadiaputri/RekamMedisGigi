<?php 
echo $firstname;
?>